Assalamualaikum Wr. Wb

Berikut project dari Tugas Besar Teori Bahasa dan Otomata mengenai aplikasi pemenggalan kata yang dikerjakan oleh tim kami yaitu Muhammad Rifky Prayanta (180535632608) dan Gandis Helen Karamoy (190535646090)

Atau dapat dibuka di link sebagai berikut http://sukukata.unavelstudio.com/

Terimakasih 