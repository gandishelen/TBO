<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FormController extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->library('session');
		$this->load->model('formModel');
	}

	public function index()
	{
		$data['judul'] = 'Halaman Cari Suku Kata';
		$this->load->view('formTampil', $data);
	}

	public function proses_sukukata()
	{
		$data['judul'] = 'Halaman Cari Suku Kata';
		$kata =  $this->input->post('kata');
		//$data['suku'] = explode(" ", $kata);
		$arr_kata = explode(" ", $kata);
		// $data['hasil'] = $this->formModel->cari_kata($arr_kata);
		$data['kata'] = '';
		$data['suku_kata'] = '';
		foreach ($this->formModel->cari_kata($arr_kata) as $a ) {
			$data['kata'] .= $a[0]->kata.' ';
			$data['suku_kata'] .= $a[0]->suku_kata.' ';
		}

		if($this->db->affected_rows() > 0)
		{
			$this->session->set_flashdata('ditemukan', 'Data ditemukan dalam database');
		}
		else
		{
			$this->session->set_flashdata('gagal', 'Data tidak ditemukan dalam database');
		}
		$this->load->view('formTampil', $data);
	}

	public function tampil_sukukata()
	{
		$data['judul'] = 'Tabel Suku Kata';
        $data['hasil'] = $this->formModel->tampil_data();
		$this->load->view('tabel_sukukata', $data);
	}


	public function tambah_sukukata()
	{
		if(isset($_POST['submit'])){  
			$data = array(
            'kata'      =>  $this->input->post('kata'),
            'suku_kata'      =>  $this->input->post('suku_kata'),
            'jenis'      =>  $this->input->post('jenis'));

            $this->formModel->tambah_sukukata($data);
            redirect('formController/tampil_sukukata','');
        }else{
        	$data['judul'] = 'Tambah Suku Kata';
			$this->load->view('tambah_sukukata', $data);
        }
	}


	public function edit_sukukata($id_sukukata)
	{
		if(isset($_POST['submit'])){  
			$data = array(
            'kata'      =>  $this->input->post('kata'),
            'suku_kata'      =>  $this->input->post('suku_kata'),
            'jenis'      =>  $this->input->post('jenis'));

            $this->formModel->update_data($data, $id_sukukata);
            redirect('formController/tampil_sukukata','');
         }
         else
         {
         	$data['judul'] = 'Edit Suku Kata';
         	$id_sukukata = $this->uri->segment(3);
         	$data['hasil'] = $this->formModel->tampil_data_ubah($id_sukukata);
         	//$data['sukukata'] = array('id_sukukata'=>$this->uri->segment(3));
			$this->load->view('edit_sukukata', $data);
         }
	}



	public function hapus_sukukata($id_sukukata)
	{
		$data['judul'] = 'Tabel Suku Kata';
		$this->formModel->hapus_sukukata($id_sukukata);
        $data['hasil'] = $this->formModel->tampil_data();
		$this->load->view('tabel_sukukata', $data);
	}
}

/* End of file formController.php */
/* Location: ./application/controllers/formController.php */