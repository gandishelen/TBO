<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/bootstrap.min.css') ;?>">

    <title>Pemenggalan Suku Kata Berbasis Web</title>
  </head>
  <body>
    <div class="container">

    <div class="jumbotron">
      <h1 class="display-6"><?php echo $judul ?></h1>
        <p class="lead">Tabel Suku Kata.</p>
      <hr class="my-3">
        
        <table id="tabel" class="table table-stripped table-bordered" style="width:100%">
      <thead>
        <tr>
        <th>No</th>
        <th>Kata</th>
        <th>Jenis</th>
      </tr>
      </thead>
      <tbody>
        <!-- memanggil data dari controller ruangan function fasilitas dengan var. fasilitas -->
        <?php $no=1; foreach($hasil as $a)
          { ?>
        <tr>
          <td><?php echo $no  ?></td>
          <td><?php echo $a->kata; ?></td>
          <td><?php echo $a->jenis; ?></td>
<!-- 
          <td><a href="<?php echo base_url('ruangan/edit_fasilitas/'.$a->id_fasilitas);?>" class="btn btn-success">Edit</a>&nbsp<a href="<?php echo base_url('ruangan/delete_fasilitas/'.$a->id_fasilitas
          );?>" onclick="return confirm('Ingin menghapus data?');" class="btn btn-danger">Delete</a></td>  -->
        </tr>
        <?php $no++;
        } 
        ?>
      </tbody>

    </div> 
  </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo base_url('assets/dist/js/jquery-3.3.1.slim.min.js');?>"></script>
    <script src="<?php echo base_url('assets/dist/js/bootstrap.min.js');?>"></script>
  </body>
</html>


