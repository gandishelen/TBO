<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/bootstrap.min.css') ;?>">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <title>Pemenggalan Suku Kata Berbasis Web</title>
  </head>
  <body>
  	<div class="container">

    <div class="jumbotron">
      <h1 class="display-6"><?php echo $judul ?></h1>
        <p class="lead">Program pemenggalan kata berbasis Website. Anda dapat memasukkan kata atau kalimat dan melihat hasil dari pemenggalan kata.</p>
        <a href="<?php echo base_url('formController/tampil_sukukata/')?>" class="btn btn-success">Tabel Suku Kata</a>
      <hr class="my-3">
      <form action="<?php echo base_url('formController/proses_sukukata')?>" class="form-horizontal" method="post">
        <div class="form-group">
          <label for="exampleFormControlTextarea1">Masukkan Kata / Kalimat : </label>
          <textarea name="kata" class="form-control rounded-0" id="exampleFormControlTextarea1" rows="5" cols="5"></textarea>
        </div>

        <button type="submit" class="btn btn-md btn-success">Cari Suku Kata</button>
          <a href="<?=site_url('/')?>" class="btn btn-danger">
            <i class="glyphicon glyphicon-remove"></i> Reset
          </a>
      </form>
      <br>
      <?php if(isset($kata)) { ?>
        <?php if($this->session->flashdata('ditemukan')) { ?>
          <div class="alert alert-info" role="alert">
            <?php echo $this->session->flashdata('ditemukan'); ?>
          </div>
        <?php }
        else if($this->session->flashdata('gagal')) { ?>
          <div class="alert alert-danger" role="alert">
            <?php echo $this->session->flashdata('gagal'); ?>
          </div>
        <?php } ?>
          <div class="alert alert-primary" role="alert">
              Kata / Kalimat Awal : <b> <?php echo $kata;  ?> </b> <br>
              Pemenggalan Kata / Kalimat : <b><?php echo $suku_kata; ?> </b>
          </div>
        <?php  }  ?>
    </div> 
	</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo base_url('assets/dist/js/jquery-3.3.1.slim.min.js');?>"></script>
    <script src="<?php echo base_url('assets/dist/js/bootstrap.min.js');?>"></script>
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
  </body>
</html>


