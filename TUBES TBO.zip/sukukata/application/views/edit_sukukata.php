<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/bootstrap.min.css') ;?>">

    <title>Pemenggalan Suku Kata Berbasis Web</title>
  </head>
  <body>
  	<div class="container">

    <div class="jumbotron">
      <h1 class="display-6">Edit Suku Kata</h1>
        <p class="lead">Tambahkan Suku Kata.</p>
      <hr class="my-3">
      <?php foreach ($hasil as $a)
         {

         ?>
      <form action="<?php echo base_url('formController/edit_sukukata/'.$a->id_sukukata)?>" class="form-horizontal" method="post">

        <div class="form-group">
            <label class="col-lg-2 control-label">Kata :  </label>
            <div class="col-lg-5">
                <input type="text" name="kata" class="form-control"   value="<?php echo $a->kata; ?>" placeholder="Masukkan Kata Bahasa">
            </div>
        </div>

         <div class="form-group">
            <label class="col-lg-2 control-label">Suku Kata :  </label>
            <div class="col-lg-5">
                <input type="text" name="suku_kata" class="form-control" value="<?php echo $a->suku_kata; ?>"  placeholder="Masukkan Suku Kata Bahasa">
            </div>
        </div>

        <div class="form-group">
            <label class="col-lg-2 control-label">Jenis :  </label>
            <div class="col-lg-5">
                <input type="text" name="jenis" class="form-control" value="<?php echo $a->jenis; ?>"  placeholder="Masukkan Jenis Kata Bahasa">
            </div>
        </div>


        <div class="form-group">
            <label class="col-lg-2 control-label"></label>
            <div class="col-lg-5">
                <button class="btn btn-primary" type="submit" name="submit">
                    <i class="glyphicon glyphicon-ok"></i>
                    Submit
                </button>

                <a href="<?=site_url('formController/edit_sukukata/'.$a->id_sukukata)?>" class="btn btn-danger">
                    <i class="glyphicon glyphicon-remove"></i>
                    cancel
                </a>
            </div>
        </div>
        
      </form>

  <?php }?>
     
    </div> 
	</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo base_url('assets/dist/js/jquery-3.3.1.slim.min.js');?>"></script>
    <script src="<?php echo base_url('assets/dist/js/bootstrap.min.js');?>"></script>
  </body>
</html>


