<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/dist/css/bootstrap.min.css') ;?>">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">

    <title>Pemenggalan Suku Kata Berbasis Web</title>
  </head>
  <body>
    <div class="container">

    <div class="jumbotron">
      <h1 class="display-6"><?php echo $judul ?></h1>
        <p class="lead">Tabel Suku Kata.</p>
        <a href="<?php echo base_url('formController/tambah_sukukata/')?>" class="btn btn-success">Tambah Suku Kata</a>
      <hr class="my-3">
        
        <table id="table" class="table table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
        <th>No</th>
        <th>Kata</th>
        <th>Suku Kata</th>
        <th>Jenis</th>
        <th>Aksi</th>
      </tr>
      </thead>
      <tbody>
        <!-- memanggil data dari controller ruangan function fasilitas dengan var. fasilitas -->
        <?php $no=1; foreach($hasil as $a)
          { ?>
        <tr>
          <td><?php echo $no  ?></td>
          <td><?php echo $a->kata; ?></td>
          <td><?php echo $a->suku_kata; ?></td>
          <td><?php echo $a->jenis; ?></td>
           <td><a href="<?php echo base_url('formController/edit_sukukata/'.$a->id_sukukata);?>"  class="btn btn-info">Edit</a>&nbsp<a href="<?php echo base_url('formController/hapus_sukukata/'.$a->id_sukukata);?>" onclick="return confirm('Ingin menghapus data?');" class="btn btn-danger">Delete</a></td> 
        </tr>
        <?php $no++;
        } 
        ?>
      </tbody>

    </div> 
  </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo base_url('assets/dist/js/jquery-3.3.1.slim.min.js');?>"></script>
    <script src="<?php echo base_url('assets/dist/js/bootstrap.min.js');?>"></script>
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    
     <script>
      $(document).ready( function () {
        $('#table').DataTable();
      } );
    </script>
    

  </body>
</html>


