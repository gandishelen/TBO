<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FormModel extends CI_Model {

	public function tampil_data(){
		$this->db->select("a.kata, a.jenis, a.suku_kata, a.id_sukukata");
		$this->db->from("suku_kata as a");
		return $this->db->get('')->result();
	}

	public function tampil_data_ubah($id_sukukata){
		$this->db->select("a.kata, a.jenis, a.suku_kata, a.id_sukukata");
		$this->db->from("suku_kata as a");
		$this->db->where("a.id_sukukata", $id_sukukata);
		return $this->db->get('')->result();
	}
	
	public function cari($kata)
    {
    	$this->db->select("a.kata, a.suku_kata");
		$this->db->from("suku_kata as a");
		$this->db->where("a.kata", $kata);
		return $this->db->get('')->result();
	
    }

    public function cari_kata($arr_kata)
    {
    	$result_sukukata = array();

    	for($i=0; $i<count($arr_kata);$i++)
    	{
    		$this->db->select("a.kata, a.suku_kata");
			$this->db->from("suku_kata as a");
			$this->db->where("a.kata", $arr_kata[$i]);
			$tempresult = $this->db->get('')->result();

			if(!empty($tempresult))
			{
				$result_sukukata[] = $tempresult;
			}
    	}
    	return $result_sukukata;
    }

    public function tambah_sukukata($data)
    {
		$this->db->insert('suku_kata',$data);
    }

    public function update_data($data, $id_sukukata){
    	$this->db->where("id_sukukata", $id_sukukata);
		$this->db->update('suku_kata',$data);
	}	

    public function hapus_sukukata($id_sukukata){
    $this->db->where('id_sukukata', $id_sukukata);
    $this->db->delete('suku_kata'); // Untuk mengeksekusi perintah delete data
  }
	

}

/* End of file formModel.php */
/* Location: ./application/models/formModel.php */